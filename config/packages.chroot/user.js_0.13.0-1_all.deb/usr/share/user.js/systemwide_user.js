//
/******************************************************************************
 * user.js                                                                    *
 * https://github.com/pyllyukko/user.js                                       *
 ******************************************************************************/

/******************************************************************************
 * SECTION: HTML5 / APIs / DOM                                                *
 ******************************************************************************/

// PREF-DISABLED: Disable Service Workers (disabled)
// https://developer.mozilla.org/en-US/docs/Web/API/Worker
// https://developer.mozilla.org/en-US/docs/Web/API/ServiceWorker_API
// https://wiki.mozilla.org/Firefox/Push_Notifications#Service_Workers
// NOTICE-DISABLED: Disabling ServiceWorkers breaks functionality on some sites (Google Street View...)
// NOTICE-DISABLED: Disabling ServiceWorkers breaks Firefox Sync
// Unknown security implications
// CVE-2016-5259, CVE-2016-2812, CVE-2016-1949, CVE-2016-5287 (fixed)
//pref("dom.serviceWorkers.enabled",				false);

// PREF-DISABLED: Disable web notifications (disabled)
// https://support.mozilla.org/en-US/questions/1140439
//pref("dom.webnotifications.enabled",			false);

// PREF: Disable DOM timing API
// https://wiki.mozilla.org/Security/Reviews/Firefox/NavigationTimingAPI
// https://www.w3.org/TR/navigation-timing/#privacy
pref("dom.enable_performance",				false);

// PREF-DISABLED: Disable resource timing API
// https://www.w3.org/TR/resource-timing/#privacy-security
// NOTICE-DISABLED: Disabling resource timing API breaks some DDoS protection pages (Cloudflare)
//pref("dom.enable_resource_timing",				false);

// PREF: Make sure the User Timing API does not provide a new high resolution timestamp
// https://trac.torproject.org/projects/tor/ticket/16336
// https://www.w3.org/TR/2013/REC-user-timing-20131212/#privacy-security
pref("dom.enable_user_timing",				false);

// PREF-DISABLED: Disable Web Audio API (disabled)
// https://bugzilla.mozilla.org/show_bug.cgi?id=1288359
// NOTICE-DISABLED: Web Audio API is required for Unity web player/games
//pref("dom.webaudio.enabled",				false);

// PREF-DISABLED: Disable Location-Aware Browsing (geolocation) (disabled)
// https://www.mozilla.org/en-US/firefox/geolocation/
//pref("geo.enabled",					false);

// PREF: When geolocation is enabled, use Mozilla geolocation service instead of Google
// https://bugzilla.mozilla.org/show_bug.cgi?id=689252
pref("geo.wifi.uri", "https://location.services.mozilla.com/v1/geolocate?key=%MOZILLA_API_KEY%");

// PREF: When geolocation is enabled, don't log geolocation requests to the console
pref("geo.wifi.logging.enabled", false);

// PREF: Disable raw TCP socket support (mozTCPSocket)
// https://trac.torproject.org/projects/tor/ticket/18863
// https://www.mozilla.org/en-US/security/advisories/mfsa2015-97/
// https://developer.mozilla.org/docs/Mozilla/B2G_OS/API/TCPSocket
pref("dom.mozTCPSocket.enabled",				false);

// PREF-DISABLED: Disable DOM storage (disabled)
// http://kb.mozillazine.org/Dom.storage.enabled
// https://html.spec.whatwg.org/multipage/webstorage.html
// NOTICE-DISABLED: Disabling DOM storage is known to cause`TypeError: localStorage is null` errors
//pref("dom.storage.enabled",		false);

// PREF: Disable leaking network/browser connection information via Javascript
// Network Information API provides general information about the system's connection type (WiFi, cellular, etc.)
// https://developer.mozilla.org/en-US/docs/Web/API/Network_Information_API
// https://wicg.github.io/netinfo/#privacy-considerations
// https://bugzilla.mozilla.org/show_bug.cgi?id=960426
pref("dom.netinfo.enabled",				false);

// PREF: Disable network API (Firefox < 32)
// https://developer.mozilla.org/en-US/docs/Web/API/Connection/onchange
// https://www.torproject.org/projects/torbrowser/design/#fingerprinting-defenses
pref("dom.network.enabled",				false);

// PREF-DISABLED: Disable WebRTC entirely to prevent leaking internal IP addresses (Firefox < 42) (disabled)
// NOTICE-DISABLED: Disabling WebRTC breaks peer-to-peer file sharing tools and camera/microphone integration
//pref("media.peerconnection.enabled",			false);

// PREF: Don't reveal your internal IP when WebRTC is enabled (Firefox >= 42)
// https://wiki.mozilla.org/Media/WebRTC/Privacy
// https://github.com/beefproject/beef/wiki/Module%3A-Get-Internal-IP-WebRTC
pref("media.peerconnection.ice.default_address_only",	true); // Firefox 42-51
pref("media.peerconnection.ice.no_host",			true); // Firefox >= 52

// PREF-DISABLED: Disable WebRTC getUserMedia, screen sharing, audio capture, video capture (disabled)
// NOTICE-DISABLED: Disabling media.navigator.* breaks peer-to-peer file sharing tools and camera/microphone integration
// https://wiki.mozilla.org/Media/getUserMedia
// https://blog.mozilla.org/futurereleases/2013/01/12/capture-local-camera-and-microphone-streams-with-getusermedia-now-enabled-in-firefox/
// https://developer.mozilla.org/en-US/docs/Web/API/Navigator
//pref("media.navigator.enabled",				false);
//pref("media.navigator.video.enabled",			false);
//pref("media.getusermedia.screensharing.enabled",		false);
//pref("media.getusermedia.audiocapture.enabled",		false);

// PREF: Disable battery API (Firefox < 52)
// https://developer.mozilla.org/en-US/docs/Web/API/BatteryManager
// https://bugzilla.mozilla.org/show_bug.cgi?id=1313580
pref("dom.battery.enabled",				false);

// PREF: Disable telephony API
// https://wiki.mozilla.org/WebAPI/Security/WebTelephony
pref("dom.telephony.enabled",				false);

// PREF: Disable "beacon" asynchronous HTTP transfers (used for analytics)
// https://developer.mozilla.org/en-US/docs/Web/API/navigator.sendBeacon
pref("beacon.enabled",					false);

// PREF-DISABLED: Disable clipboard event detection (onCut/onCopy/onPaste) via Javascript
// https://web.archive.org/web/20210416195937/https://developer.mozilla.org/en-US/docs/Mozilla/Preferences/Preference_reference/dom.event.clipboardevents.enabled
// https://github.com/pyllyukko/user.js/issues/287
// NOTICE-DISABLED: Disabling clipboard events breaks Ctrl+C/X/V copy/cut/paste functionaility in JS-based web applications (Google Docs...)
// https://developer.mozilla.org/en-US/docs/Mozilla/Preferences/Preference_reference/dom.event.clipboardevents.enabled
//pref("dom.event.clipboardevents.enabled",			false);

// PREF-DISABLED: Disable "copy to clipboard" functionality via Javascript (Firefox >= 41) (disabled)
// NOTICE: Disabling clipboard operations will break legitimate JS-based "copy to clipboard" functionality
// https://hg.mozilla.org/mozilla-central/rev/2f9f8ea4b9c3
//pref("dom.allow_cut_copy", false);

// PREF: Disable speech recognition
// https://dvcs.w3.org/hg/speech-api/raw-file/tip/speechapi.html
// https://developer.mozilla.org/en-US/docs/Web/API/SpeechRecognition
// https://wiki.mozilla.org/HTML5_Speech_API
pref("media.webspeech.recognition.enable",			false);

// PREF: Disable speech synthesis
// https://developer.mozilla.org/en-US/docs/Web/API/SpeechSynthesis
pref("media.webspeech.synth.enabled",			false);

// PREF: Disable sensor API
// https://wiki.mozilla.org/Sensor_API
pref("device.sensors.enabled",				false);

// PREF: Disable pinging URIs specified in HTML <a> ping= attributes
// http://kb.mozillazine.org/Browser.send_pings
pref("browser.send_pings",					false);

// PREF: When browser pings are enabled, only allow pinging the same host as the origin page
// http://kb.mozillazine.org/Browser.send_pings.require_same_host
pref("browser.send_pings.require_same_host",		true);

// PREF-DISABLED: Disable IndexedDB (disabled)
// https://developer.mozilla.org/en-US/docs/IndexedDB
// https://en.wikipedia.org/wiki/Indexed_Database_API
// https://wiki.mozilla.org/Security/Reviews/Firefox4/IndexedDB_Security_Review
// http://forums.mozillazine.org/viewtopic.php?p=13842047
// https://github.com/pyllyukko/user.js/issues/8
// NOTICE-DISABLED: IndexedDB could be used for tracking purposes, but is required for some add-ons to work (notably uBlock), so is left enabled
//pref("dom.indexedDB.enabled",		false);

// TODO: "Access Your Location" "Maintain Offline Storage" "Show Notifications"

// PREF: Disable gamepad API to prevent USB device enumeration
// https://www.w3.org/TR/gamepad/
// https://trac.torproject.org/projects/tor/ticket/13023
pref("dom.gamepad.enabled",				false);

// PREF: Disable virtual reality devices APIs
// https://developer.mozilla.org/en-US/Firefox/Releases/36#Interfaces.2FAPIs.2FDOM
// https://developer.mozilla.org/en-US/docs/Web/API/WebVR_API
pref("dom.vr.enabled",					false);

// PREF: Disable vibrator API
pref("dom.vibrator.enabled",           false);

// PREF: Disable Archive API (Firefox < 54)
// https://wiki.mozilla.org/WebAPI/ArchiveAPI
// https://bugzilla.mozilla.org/show_bug.cgi?id=1342361
pref("dom.archivereader.enabled",				false);

// PREF-DISABLED: Disable webGL (disabled)
// https://en.wikipedia.org/wiki/WebGL
// https://www.contextis.com/resources/blog/webgl-new-dimension-browser-exploitation/
// NOTICE-DISABLED: Disabling WebGL breaks WebGL-based websites/applications (windy, meteoblue...)
// pref("webgl.disabled",					true);

// PREF-DISABLED: When webGL is enabled, use the minimum capability mode (disabled)
// pref("webgl.min_capability_mode",				true);

// PREF-DISABLED: When webGL is enabled, disable webGL extensions (disabled)
// https://developer.mozilla.org/en-US/docs/Web/API/WebGL_API#WebGL_debugging_and_testing
//pref("webgl.disable-extensions",				true);

// PREF-DISABLED: When webGL is enabled, force enabling it even when layer acceleration is not supported
// https://trac.torproject.org/projects/tor/ticket/18603
pref("webgl.disable-fail-if-major-performance-caveat",	true);

// PREF-DISABLED: When webGL is enabled, do not expose information about the graphics driver
// https://bugzilla.mozilla.org/show_bug.cgi?id=1171228
// https://developer.mozilla.org/en-US/docs/Web/API/WEBGL_debug_renderer_info
pref("webgl.enable-debug-renderer-info",			false);
// somewhat related...
//pref("pdfjs.enableWebGL",					false);

// PREF: Spoof dual-core CPU
// https://trac.torproject.org/projects/tor/ticket/21675
// https://bugzilla.mozilla.org/show_bug.cgi?id=1360039
pref("dom.maxHardwareConcurrency",				2);

// PREF-DISABLED: Disable WebAssembly (disabled)
// https://webassembly.org/
// https://en.wikipedia.org/wiki/WebAssembly
// https://trac.torproject.org/projects/tor/ticket/21549
// NOTICE-DISABLED: WebAssembly is required for Unity web player/games
//pref("javascript.options.wasm",				false);

/******************************************************************************
 * SECTION: Misc                                                              *
 ******************************************************************************/

// PREF: Disable face detection
pref("camera.control.face_detection.enabled",		false);

// PREF: Disable GeoIP lookup on your address to set default search engine region
// https://trac.torproject.org/projects/tor/ticket/16254
// https://support.mozilla.org/en-US/kb/how-stop-firefox-making-automatic-connections#w_geolocation-for-default-search-engine
pref("browser.search.countryCode",				"US");
pref("browser.search.region",				"US");
pref("browser.search.geoip.url",				"");

// PREF-DISABLED: Set Accept-Language HTTP header to en-US regardless of Firefox localization (disabled)
// https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Accept-Language
//pref("intl.accept_languages",				"en-US, en");

// PREF-DISABLED: Don't use OS values to determine locale, force using Firefox locale setting (disabled)
// http://kb.mozillazine.org/Intl.locale.matchOS
//pref("intl.locale.matchOS",				false);

// Use LANG environment variable to choose locale
pref("intl.locale.requested", "");

// PREF: Don't use Mozilla-provided location-specific search engines
pref("browser.search.geoSpecificDefaults",			false);

// PREF-DISABLED: Do not automatically send selection to clipboard on some Linux platforms
// http://kb.mozillazine.org/Clipboard.autocopy
pref("clipboard.autocopy",					false);

// PREF: Prevent leaking application locale/date format using JavaScript
// https://bugzilla.mozilla.org/show_bug.cgi?id=867501
// https://hg.mozilla.org/mozilla-central/rev/52d635f2b33d
pref("javascript.use_us_english_locale",			true);

// PREF-DISABLED: Do not submit invalid URIs entered in the address bar to the default search engine (disabled)
// http://kb.mozillazine.org/Keyword.enabled
//pref("keyword.enabled",					false);

// PREF: Don't trim HTTP off of URLs in the address bar.
// https://bugzilla.mozilla.org/show_bug.cgi?id=665580
pref("browser.urlbar.trimURLs",				false);

// PREF: Disable preloading of autocomplete URLs.
// https://wiki.mozilla.org/Privacy/Privacy_Task_Force/firefox_about_config_privacy_tweeks
pref("browser.urlbar.speculativeConnect.enabled", false);

// PREF: Don't try to guess domain names when entering an invalid domain name in URL bar
// http://www-archive.mozilla.org/docs/end-user/domain-guessing.html
pref("browser.fixup.alternate.enabled",			false);

// PREF: When browser.fixup.alternate.enabled is enabled, strip password from 'user:password@...' URLs
// https://github.com/pyllyukko/user.js/issues/290#issuecomment-303560851
pref("browser.fixup.hide_user_pass", true);

// PREF: Send DNS request through SOCKS when SOCKS proxying is in use
// https://trac.torproject.org/projects/tor/wiki/doc/TorifyHOWTO/WebBrowsers
pref("network.proxy.socks_remote_dns",			true);

// PREF: Don't monitor OS online/offline connection state
// https://trac.torproject.org/projects/tor/ticket/18945
pref("network.manage-offline-status",			false);

// PREF: Enforce Mixed Active Content Blocking
// https://support.mozilla.org/t5/Protect-your-privacy/Mixed-content-blocking-in-Firefox/ta-p/10990
// https://developer.mozilla.org/en-US/docs/Site_Compatibility_for_Firefox_23#Non-SSL_contents_on_SSL_pages_are_blocked_by_default
// https://blog.mozilla.org/tanvi/2013/04/10/mixed-content-blocking-enabled-in-firefox-23/
pref("security.mixed_content.block_active_content",	true);

// PREF: Enforce Mixed Passive Content blocking (a.k.a. Mixed Display Content)
// NOTICE: Enabling Mixed Display Content blocking can prevent images/styles... from loading properly when connection to the website is only partially secured
pref("security.mixed_content.block_display_content",	true);

// PREF: Disable JAR from opening Unsafe File Types
// http://kb.mozillazine.org/Network.jar.open-unsafe-types
// CIS Mozilla Firefox 24 ESR v1.0.0 - 3.7 
pref("network.jar.open-unsafe-types",			false);

// CIS 2.7.4 Disable Scripting of Plugins by JavaScript
// http://forums.mozillazine.org/viewtopic.php?f=7&t=153889
pref("security.xpconnect.plugin.unrestricted",		false);

// PREF: Set File URI Origin Policy
// http://kb.mozillazine.org/Security.fileuri.strict_origin_policy
// CIS Mozilla Firefox 24 ESR v1.0.0 - 3.8
pref("security.fileuri.strict_origin_policy",		true);

// PREF: Disable Displaying Javascript in History URLs
// http://kb.mozillazine.org/Browser.urlbar.filter.javascript
// CIS 2.3.6 
pref("browser.urlbar.filter.javascript",			true);

// PREF-DISABLED: Disable asm.js (disabled)
// http://asmjs.org/
// https://www.mozilla.org/en-US/security/advisories/mfsa2015-29/
// https://www.mozilla.org/en-US/security/advisories/mfsa2015-50/
// https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2015-2712
// NOTICE-DISABLED: Fixed in Firefox 36, disabling harms performance
//pref("javascript.options.asmjs",				false);

// PREF: Disable SVG in OpenType fonts
// https://wiki.mozilla.org/SVGOpenTypeFonts
// https://github.com/iSECPartners/publications/tree/master/reports/Tor%20Browser%20Bundle
pref("gfx.font_rendering.opentype_svg.enabled",		false);

// PREF-DISABLED: Disable in-content SVG rendering (Firefox >= 53) (disabled)
// NOTICE-DISABLED: Disabling SVG support breaks many UI elements on many sites
// https://bugzilla.mozilla.org/show_bug.cgi?id=1216893
// https://github.com/iSECPartners/publications/raw/master/reports/Tor%20Browser%20Bundle/Tor%20Browser%20Bundle%20-%20iSEC%20Deliverable%201.3.pdf#16
//pref("svg.disabled", true);


// PREF: Disable video stats to reduce fingerprinting threat
// https://bugzilla.mozilla.org/show_bug.cgi?id=654550
// https://github.com/pyllyukko/user.js/issues/9#issuecomment-100468785
// https://github.com/pyllyukko/user.js/issues/9#issuecomment-148922065
pref("media.video_stats.enabled",				false);

// PREF: Don't reveal build ID
// Value taken from Tor Browser
// https://bugzilla.mozilla.org/show_bug.cgi?id=583181
pref("general.buildID.override",				"20100101");
pref("browser.startup.homepage_override.buildID",		"20100101");

// PREF-DISABLED: Don't use document specified fonts to prevent installed font enumeration (fingerprinting) (disabled)
// https://github.com/pyllyukko/user.js/issues/395
// https://browserleaks.com/fonts
// https://github.com/pyllyukko/user.js/issues/120
//pref("browser.display.use_document_fonts",			0);

// PREF: Enable only whitelisted URL protocol handlers
// http://kb.mozillazine.org/Network.protocol-handler.external-default
// http://kb.mozillazine.org/Network.protocol-handler.warn-external-default
// http://kb.mozillazine.org/Network.protocol-handler.expose.%28protocol%29
// https://news.ycombinator.com/item?id=13047883
// https://bugzilla.mozilla.org/show_bug.cgi?id=167475
// https://github.com/pyllyukko/user.js/pull/285#issuecomment-298124005
// NOTICE: Disabling nonessential protocols breaks all interaction with custom protocols such as mailto:, irc:, magnet: ... and breaks opening third-party mail/messaging/torrent/... clients when clicking on links with these protocols
// TODO: Add externally-handled protocols from Windows 8.1 and Windows 10 (currently contains protocols only from Linux and Windows 7) that might pose a similar threat (see e.g. https://news.ycombinator.com/item?id=13044991)
// TODO: Add externally-handled protocols from Mac OS X that might pose a similar threat (see e.g. https://news.ycombinator.com/item?id=13044991)
// If you want to enable a protocol, set network.protocol-handler.expose.(protocol) to true and network.protocol-handler.external.(protocol) to:
//   * true, if the protocol should be handled by an external application
//   * false, if the protocol should be handled internally by Firefox
pref("network.protocol-handler.warn-external-default",	true);
pref("network.protocol-handler.external.http",		false);
pref("network.protocol-handler.external.https",		false);
pref("network.protocol-handler.external.javascript",	false);
pref("network.protocol-handler.external.moz-extension",	false);
pref("network.protocol-handler.external.ftp",		false);
pref("network.protocol-handler.external.file",		false);
pref("network.protocol-handler.external.about",		false);
pref("network.protocol-handler.external.chrome",		false);
pref("network.protocol-handler.external.blob",		false);
pref("network.protocol-handler.external.data",		false);
pref("network.protocol-handler.external.magnet",		true);
pref("network.protocol-handler.external.mailto",		true);
pref("network.protocol-handler.expose-all",		false);
pref("network.protocol-handler.expose.http",		true);
pref("network.protocol-handler.expose.https",		true);
pref("network.protocol-handler.expose.javascript",		true);
pref("network.protocol-handler.expose.moz-extension",	true);
pref("network.protocol-handler.expose.ftp",		true);
pref("network.protocol-handler.expose.file",		true);
pref("network.protocol-handler.expose.about",		true);
pref("network.protocol-handler.expose.chrome",		true);
pref("network.protocol-handler.expose.blob",		true);
pref("network.protocol-handler.expose.data",		true);
pref("network.protocol-handler.expose.magnet",		true);
pref("network.protocol-handler.expose.mailto",		true);

/******************************************************************************
 * SECTION: Extensions / plugins                                                       *
 ******************************************************************************/

// PREF: Ensure you have a security delay when installing add-ons (milliseconds)
// http://kb.mozillazine.org/Disable_extension_install_delay_-_Firefox
// http://www.squarefree.com/2004/07/01/race-conditions-in-security-dialogs/
pref("security.dialog_enable_delay",			1000);

// PREF: Require signatures
// https://wiki.mozilla.org/Addons/Extension_Signing
pref("xpinstall.signatures.required",		true);

// PREF: Opt-out of add-on metadata updates
// https://blog.mozilla.org/addons/how-to-opt-out-of-add-on-metadata-updates/
pref("extensions.getAddons.cache.enabled",			false);

// PREF: Opt-out of themes (Persona) updates
// https://support.mozilla.org/t5/Firefox/how-do-I-prevent-autoamtic-updates-in-a-50-user-environment/td-p/144287
pref("lightweightThemes.update.enabled",			false);

// PREF: Disable Flash Player NPAPI plugin
// http://kb.mozillazine.org/Flash_plugin
pref("plugin.state.flash",					0);

// PREF: Disable Java NPAPI plugin
pref("plugin.state.java",					0);

// PREF: Disable sending Flash Player crash reports
pref("dom.ipc.plugins.flash.subprocess.crashreporter.enabled",	false);

// PREF: When Flash crash reports are enabled, don't send the visited URL in the crash report
pref("dom.ipc.plugins.reportCrashURL",			false);

// PREF: When Flash is enabled, download and use Mozilla SWF URIs blocklist
// https://bugzilla.mozilla.org/show_bug.cgi?id=1237198
// https://github.com/mozilla-services/shavar-plugin-blocklist
pref("browser.safebrowsing.blockedURIs.enabled", true);

// PREF: Disable Gnome Shell Integration NPAPI plugin
pref("plugin.state.libgnome-shell-browser-plugin",		0);

// PREF: Disable the bundled OpenH264 video codec
// http://forums.mozillazine.org/viewtopic.php?p=13845077&sid=28af2622e8bd8497b9113851676846b1#p13845077
pref("media.gmp-provider.enabled",		false);

// PREF: Enable plugins click-to-play
// https://wiki.mozilla.org/Firefox/Click_To_Play
// https://blog.mozilla.org/security/2012/10/11/click-to-play-plugins-blocklist-style/
pref("plugins.click_to_play",				true);

// PREF: Updates addons automatically
// https://blog.mozilla.org/addons/how-to-turn-off-add-on-updates/
pref("extensions.update.enabled",				true);

// PREF: Enable add-on and certificate blocklists (OneCRL) from Mozilla
// https://wiki.mozilla.org/Blocklisting
// https://blocked.cdn.mozilla.net/
// http://kb.mozillazine.org/Extensions.blocklist.enabled
// http://kb.mozillazine.org/Extensions.blocklist.url
// https://blog.mozilla.org/security/2015/03/03/revoking-intermediate-certificates-introducing-onecrl/
// Updated at interval defined in extensions.blocklist.interval (default: 86400)
pref("extensions.blocklist.enabled",			true);
pref("services.blocklist.update_enabled",			true);

// PREF: Decrease system information leakage to Mozilla blocklist update servers
// https://trac.torproject.org/projects/tor/ticket/16931
pref("extensions.blocklist.url",				"https://blocklist.addons.mozilla.org/blocklist/3/%APP_ID%/%APP_VERSION%/");

// PREF: Disable system add-on updates (hidden & always-enabled add-ons from Mozilla)
// https://firefox-source-docs.mozilla.org/toolkit/mozapps/extensions/addon-manager/SystemAddons.html
// https://blog.mozilla.org/data/2018/08/20/effectively-measuring-search-in-firefox/
// https://github.com/pyllyukko/user.js/issues/419
// https://dxr.mozilla.org/mozilla-central/source/toolkit/mozapps/extensions/AddonManager.jsm#1248-1257
// NOTICE: Disabling system add-on updates prevents Mozilla from "hotfixing" your browser to patch critical problems (one possible use case from the documentation)
pref("extensions.systemAddon.update.enabled",		false);

/******************************************************************************
 * SECTION: Firefox (anti-)features / components                              *                            *
 ******************************************************************************/

// PREF: Disable Extension recommendations (Firefox >= 65)
// https://support.mozilla.org/en-US/kb/extension-recommendations
pref("browser.newtabpage.activity-stream.asrouter.userprefs.cfr",	false);

// PREF-DISABLED: Trusted Recursive Resolver (DNS-over-HTTPS) (disabled)
// https://wiki.mozilla.org/Trusted_Recursive_Resolver
//pref("network.trr.mode",					0);

// PREF: Disable WebIDE
// https://trac.torproject.org/projects/tor/ticket/16222
// https://developer.mozilla.org/docs/Tools/WebIDE
pref("devtools.webide.enabled",				false);
pref("devtools.webide.autoinstallADBHelper",		false);
pref("devtools.webide.autoinstallFxdtAdapters",		false);

// PREF: Disable remote debugging
// https://developer.mozilla.org/en-US/docs/Tools/Remote_Debugging/Debugging_Firefox_Desktop
// https://developer.mozilla.org/en-US/docs/Tools/Tools_Toolbox#Advanced_settings
pref("devtools.debugger.remote-enabled",			false);
pref("devtools.chrome.enabled",				false);
pref("devtools.debugger.force-local",			true);

// PREF: Disable Mozilla telemetry/experiments
// https://wiki.mozilla.org/Platform/Features/Telemetry
// https://wiki.mozilla.org/Privacy/Reviews/Telemetry
// https://wiki.mozilla.org/Telemetry
// https://www.mozilla.org/en-US/legal/privacy/firefox.html#telemetry
// https://support.mozilla.org/t5/Firefox-crashes/Mozilla-Crash-Reporter/ta-p/1715
// https://wiki.mozilla.org/Security/Reviews/Firefox6/ReviewNotes/telemetry
// https://gecko.readthedocs.io/en/latest/browser/experiments/experiments/manifest.html
// https://wiki.mozilla.org/Telemetry/Experiments
// https://support.mozilla.org/en-US/questions/1197144
// https://firefox-source-docs.mozilla.org/toolkit/components/telemetry/telemetry/internals/preferences.html#id1
pref("toolkit.telemetry.enabled",				false);
pref("toolkit.telemetry.unified",				false);
pref("toolkit.telemetry.archive.enabled",			false);
pref("experiments.supported",				false);
pref("experiments.enabled",				false);
pref("experiments.manifest.uri",				"");

// PREF: Disallow Necko to do A/B testing
// https://trac.torproject.org/projects/tor/ticket/13170
pref("network.allow-experiments",				false);

// PREF: Disable sending Firefox crash reports to Mozilla servers
// https://wiki.mozilla.org/Breakpad
// http://kb.mozillazine.org/Breakpad
// https://dxr.mozilla.org/mozilla-central/source/toolkit/crashreporter
// https://bugzilla.mozilla.org/show_bug.cgi?id=411490
// A list of submitted crash reports can be found at about:crashes
pref("breakpad.reportURL",					"");

// PREF: Disable sending reports of tab crashes to Mozilla (about:tabcrashed), don't nag user about unsent crash reports
// https://hg.mozilla.org/mozilla-central/file/tip/browser/app/profile/firefox.js
pref("browser.tabs.crashReporting.sendReport",		false);
pref("browser.crashReports.unsubmittedCheck.enabled",	false);

// PREF: Disable FlyWeb (discovery of LAN/proximity IoT devices that expose a Web interface)
// https://wiki.mozilla.org/FlyWeb
// https://wiki.mozilla.org/FlyWeb/Security_scenarios
// https://docs.google.com/document/d/1eqLb6cGjDL9XooSYEEo7mE-zKQ-o-AuDTcEyNhfBMBM/edit
// http://www.ghacks.net/2016/07/26/firefox-flyweb
pref("dom.flyweb.enabled",					false);

// PREF: Disable the UITour backend
// https://trac.torproject.org/projects/tor/ticket/19047#comment:3
pref("browser.uitour.enabled",				false);

// PREF: Enable Firefox Tracking Protection
// https://wiki.mozilla.org/Security/Tracking_protection
// https://support.mozilla.org/en-US/kb/tracking-protection-firefox
// https://support.mozilla.org/en-US/kb/tracking-protection-pbm
// https://kontaxis.github.io/trackingprotectionfirefox/
// https://feeding.cloud.geek.nz/posts/how-tracking-protection-works-in-firefox/
pref("privacy.trackingprotection.enabled",			true);
pref("privacy.trackingprotection.pbmode.enabled",		true);

// PREF: Enable contextual identity Containers feature (Firefox >= 52)
// NOTICE: Containers are not available in Private Browsing mode
// https://wiki.mozilla.org/Security/Contextual_Identity_Project/Containers
pref("privacy.userContext.enabled",			true);

// PREF: Enable Firefox's anti-fingerprinting mode ("resist fingerprinting" or RFP) (Tor Uplift project)
// https://wiki.mozilla.org/Security/Tor_Uplift/Tracking
// https://bugzilla.mozilla.org/show_bug.cgi?id=1333933
// https://wiki.mozilla.org/Security/Fingerprinting
// NOTICE: RFP breaks some keyboard shortcuts used in certain websites (see #443)
// NOTICE: RFP changes your time zone
// NOTICE: RFP breaks some DDoS protection pages (Cloudflare)
pref("privacy.resistFingerprinting",			true);

// PREF: disable mozAddonManager Web API [FF57+]
// https://bugzilla.mozilla.org/buglist.cgi?bug_id=1384330
// https://bugzilla.mozilla.org/buglist.cgi?bug_id=1406795
// https://bugzilla.mozilla.org/buglist.cgi?bug_id=1415644
// https://bugzilla.mozilla.org/buglist.cgi?bug_id=1453988
// https://trac.torproject.org/projects/tor/ticket/26114
pref("privacy.resistFingerprinting.block_mozAddonManager", true);
pref("extensions.webextensions.restrictedDomains", "");

// PREF-DISABLED: enable RFP letterboxing / resizing of inner window [FF67+] (disabled)
// https://bugzilla.mozilla.org/1407366
//pref("privacy.resistFingerprinting.letterboxing", true);
//pref("privacy.resistFingerprinting.letterboxing.dimensions", "800x600, 1000x1000, 1600x900");

// PREF: disable showing about:blank/maximized window as soon as possible during startup [FF60+]
// https://bugzilla.mozilla.org/1448423
pref("browser.startup.blankWindow", false);

// PREF-DISABLED: Disable the built-in PDF viewer
// https://web.nvd.nist.gov/view/vuln/detail?vulnId=CVE-2015-2743
// https://blog.mozilla.org/security/2015/08/06/firefox-exploit-found-in-the-wild/
// https://www.mozilla.org/en-US/security/advisories/mfsa2015-69/
//pref("pdfjs.disabled",					true);

// PREF: Disable collection/sending of the health report (healthreport.sqlite*)
// https://support.mozilla.org/en-US/kb/firefox-health-report-understand-your-browser-perf
// https://gecko.readthedocs.org/en/latest/toolkit/components/telemetry/telemetry/preferences.html
pref("datareporting.healthreport.uploadEnabled",		false);
pref("datareporting.healthreport.service.enabled",		false);
pref("datareporting.policy.dataSubmissionEnabled",		false);
// "Allow Firefox to make personalized extension recommendations"
pref("browser.discovery.enabled",				false);

// PREF: Disable Shield/Heartbeat/Normandy (Mozilla user rating telemetry)
// https://wiki.mozilla.org/Advocacy/heartbeat
// https://trac.torproject.org/projects/tor/ticket/19047
// https://trac.torproject.org/projects/tor/ticket/18738
// https://wiki.mozilla.org/Firefox/Shield
// https://github.com/mozilla/normandy
// https://support.mozilla.org/en-US/kb/shield
// https://bugzilla.mozilla.org/show_bug.cgi?id=1370801
// https://wiki.mozilla.org/Firefox/Normandy/PreferenceRollout
pref("app.normandy.enabled", false);
pref("app.normandy.api_url", "");
pref("extensions.shield-recipe-client.enabled",		false);
pref("app.shield.optoutstudies.enabled",			false);


// PREF-DISABLED: Disable Firefox Hello (disabled) (Firefox < 49)
// https://wiki.mozilla.org/Loop
// https://support.mozilla.org/t5/Chat-and-share/Support-for-Hello-discontinued-in-Firefox-49/ta-p/37946
// NOTICE-DISABLED: Firefox Hello requires setting `media.peerconnection.enabled` and `media.getusermedia.screensharing.enabled` to true, `security.OCSP.require` to false to work.
//pref("loop.enabled",		false);

// PREF: Disable Firefox Hello metrics collection
// https://groups.google.com/d/topic/mozilla.dev.platform/nyVkCx-_sFw/discussion
pref("loop.logDomains",					false);

// PREF-DISABLED: Enable Auto Update (disabled)
// NOTICE: Fully automatic updates are disabled and left to package management systems on Linux. Windows users may want to change this setting.
// CIS 2.1.1
//pref("app.update.auto",					true);

// PREF-DISABLED: Enforce checking for Firefox updates (disabled)
// NOTICE-DISABLED: Update check page might incorrectly report Firefox ESR as out-of-date, let package manager handle upgrades
// http://kb.mozillazine.org/App.update.enabled
//pref("app.update.enabled",                 true);

// PREF: Enable blocking reported web forgeries
// https://wiki.mozilla.org/Security/Safe_Browsing
// http://kb.mozillazine.org/Safe_browsing
// https://support.mozilla.org/en-US/kb/how-does-phishing-and-malware-protection-work
// http://forums.mozillazine.org/viewtopic.php?f=39&t=2711237&p=12896849#p12896849
// CIS 2.3.4
pref("browser.safebrowsing.enabled",			true); // Firefox < 50
pref("browser.safebrowsing.phishing.enabled",		true); // firefox >= 50

// PREF: Enable blocking reported attack sites
// http://kb.mozillazine.org/Browser.safebrowsing.malware.enabled
// CIS 2.3.5
pref("browser.safebrowsing.malware.enabled",		true);

// PREF: Disable querying Google Application Reputation database for downloaded binary files
// https://www.mozilla.org/en-US/firefox/39.0/releasenotes/
// https://wiki.mozilla.org/Security/Application_Reputation
pref("browser.safebrowsing.downloads.remote.enabled",	false);

// PREF: Disable Pocket
// https://support.mozilla.org/en-US/kb/save-web-pages-later-pocket-firefox
// https://github.com/pyllyukko/user.js/issues/143
pref("browser.pocket.enabled",				false);
pref("extensions.pocket.enabled",				false);

// PREF: Disable "Recommended by Pocket" in Firefox Quantum
pref("browser.newtabpage.activity-stream.feeds.section.topstories",	false);

// PREF: Disable sponsored sites on new tab page
pref("browser.newtabpage.activity-stream.showSponsored",	false);
pref("browser.newtabpage.activity-stream.showSponsoredTopSites",	false);

/******************************************************************************
 * SECTION: Automatic connections                                             *
 ******************************************************************************/

// PREF-DISABLED: Limit the connection keep-alive timeout to 15 seconds (disabled)
// https://github.com/pyllyukko/user.js/issues/387
// http://kb.mozillazine.org/Network.http.keep-alive.timeout
// https://httpd.apache.org/docs/current/mod/core.html#keepalivetimeout
//pref("network.http.keep-alive.timeout",			15);

// PREF: Disable prefetching of <link rel="next"> URLs
// http://kb.mozillazine.org/Network.prefetch-next
// https://developer.mozilla.org/en-US/docs/Web/HTTP/Link_prefetching_FAQ#Is_there_a_preference_to_disable_link_prefetching.3F
pref("network.prefetch-next",				false);

// PREF: Disable DNS prefetching
// http://kb.mozillazine.org/Network.dns.disablePrefetch
// https://developer.mozilla.org/en-US/docs/Web/HTTP/Controlling_DNS_prefetching
pref("network.dns.disablePrefetch",			true);
pref("network.dns.disablePrefetchFromHTTPS",		true);

// PREF: Disable the predictive service (Necko)
// https://wiki.mozilla.org/Privacy/Reviews/Necko
pref("network.predictor.enabled",				false);

// PREF: Reject .onion hostnames before passing the to DNS
// https://bugzilla.mozilla.org/show_bug.cgi?id=1228457
// RFC 7686
pref("network.dns.blockDotOnion",				true);

// PREF: Disable search suggestions in the search bar
// http://kb.mozillazine.org/Browser.search.suggest.enabled
pref("browser.search.suggest.enabled",			false);

// PREF: Disable "Show search suggestions in location bar results"
pref("browser.urlbar.suggest.searches",			false);

// PREF-DISABLED: When using the location bar, don't suggest URLs from browsing history (disabled)
//pref("browser.urlbar.suggest.history",			false);

// PREF: Disable Firefox Suggest
// https://www.ghacks.net/2021/09/09/how-to-disable-firefox-suggest/
// https://support.mozilla.org/en-US/kb/navigate-web-faster-firefox-suggest
pref("browser.urlbar.groupLabels.enabled", false); // Firefox >= 93

// PREF: Disable SSDP
// https://bugzilla.mozilla.org/show_bug.cgi?id=1111967
pref("browser.casting.enabled",				false);

// PREF: Disable automatic downloading of OpenH264 codec
// https://support.mozilla.org/en-US/kb/how-stop-firefox-making-automatic-connections#w_media-capabilities
// https://andreasgal.com/2014/10/14/openh264-now-in-firefox/
pref("media.gmp-gmpopenh264.enabled",			false);
pref("media.gmp-manager.url",				"");

// PREF: Disable speculative pre-connections
// https://support.mozilla.org/en-US/kb/how-stop-firefox-making-automatic-connections#w_speculative-pre-connections
// https://bugzilla.mozilla.org/show_bug.cgi?id=814169
pref("network.http.speculative-parallel-limit",		0);

// PREF: Disable downloading homepage snippets/messages from Mozilla
// https://support.mozilla.org/en-US/kb/how-stop-firefox-making-automatic-connections#w_mozilla-content
// https://wiki.mozilla.org/Firefox/Projects/Firefox_Start/Snippet_Service
pref("browser.aboutHomeSnippets.updateUrl",		"");

// PREF: Never check updates for search engines
// https://support.mozilla.org/en-US/kb/how-stop-firefox-making-automatic-connections#w_auto-update-checking
pref("browser.search.update",				false);

// PREF: Disable automatic captive portal detection (Firefox >= 52.0)
// https://support.mozilla.org/en-US/questions/1157121
pref("network.captive-portal-service.enabled",		false);

// PREF: Disable (parts of?) "TopSites"
pref("browser.topsites.contile.enabled",				false);
pref("browser.newtabpage.activity-stream.feeds.topsites",		false);
pref("browser.newtabpage.activity-stream.showSponsoredTopSites",	false);

/******************************************************************************
 * SECTION: HTTP                                                              *
 ******************************************************************************/

// PREF-DISABLED: Disallow NTLMv1
// https://bugzilla.mozilla.org/show_bug.cgi?id=828183
pref("network.negotiate-auth.allow-insecure-ntlm-v1",	false);
// it is still allowed through HTTPS. uncomment the following to disable it completely.
//pref("network.negotiate-auth.allow-insecure-ntlm-v1-https",		false);

// PREF: Enable CSP 1.1 script-nonce directive support
// https://bugzilla.mozilla.org/show_bug.cgi?id=855326
pref("security.csp.experimentalEnabled",			true);

// PREF: Enable Content Security Policy (CSP)
// https://developer.mozilla.org/en-US/docs/Web/Security/CSP/Introducing_Content_Security_Policy
// https://developer.mozilla.org/en-US/docs/Web/HTTP/CSP
pref("security.csp.enable",				true);

// PREF: Enable Subresource Integrity
// https://developer.mozilla.org/en-US/docs/Web/Security/Subresource_Integrity
// https://wiki.mozilla.org/Security/Subresource_Integrity
pref("security.sri.enable",				true);

// PREF-DISABLED: DNT HTTP header (disabled)
// https://www.mozilla.org/en-US/firefox/dnt/
// https://en.wikipedia.org/wiki/Do_not_track_header
// https://dnt-dashboard.mozilla.org
// https://github.com/pyllyukko/user.js/issues/11
// NOTICE: Do No Track must be enabled manually
//pref("privacy.donottrackheader.enabled",		true);

// PREF-DISABLED: Send a referer header with the target URI as the source (disabled)
// https://bugzilla.mozilla.org/show_bug.cgi?id=822869
// https://github.com/pyllyukko/user.js/issues/227
// NOTICE-DISABLED: Spoofing referers breaks functionality on websites relying on authentic referer headers
// NOTICE-DISABLED: Spoofing referers breaks visualisation of 3rd-party sites on the Lightbeam addon
// NOTICE-DISABLED: Spoofing referers disables CSRF protection on some login pages not implementing origin-header/cookie+token based CSRF protection
// TODO: https://github.com/pyllyukko/user.js/issues/94, commented-out XOriginPolicy/XOriginTrimmingPolicy = 2 prefs
//pref("network.http.referer.spoofSource",			true);

// PREF: Don't send referer headers when following links across different domains
// https://github.com/pyllyukko/user.js/issues/227
// https://github.com/pyllyukko/user.js/issues/328
// https://feeding.cloud.geek.nz/posts/tweaking-referrer-for-privacy-in-firefox/
// https://wiki.mozilla.org/Privacy/Privacy_Task_Force/firefox_about_config_privacy_tweeks
// NOTICE: Blocking referers across same eTLD sites breaks some login flows relying on them, consider lowering this pref to 1
pref("network.http.referer.XOriginPolicy",		1);

// PREF-DISABLED: Trim HTTP referer headers to only send the scheme, host, and port
// https://wiki.mozilla.org/Privacy/Privacy_Task_Force/firefox_about_config_privacy_tweeks
//pref("network.http.referer.trimmingPolicy",	2);

// PREF-DISABLED: When sending Referer across domains, only send scheme, host, and port in the Referer header
// https://wiki.mozilla.org/Privacy/Privacy_Task_Force/firefox_about_config_privacy_tweeks
//pref("network.http.referer.XOriginTrimmingPolicy",	2);

// PREF: Accept Only 1st Party Cookies
// http://kb.mozillazine.org/Network.cookie.cookieBehavior#1
// NOTICE: Blocking 3rd-party cookies breaks a number of payment gateways
// CIS 2.5.1
pref("network.cookie.cookieBehavior",			1);

// PREF: Enable first-party isolation
// https://bugzilla.mozilla.org/show_bug.cgi?id=1299996
// https://bugzilla.mozilla.org/show_bug.cgi?id=1260931
// https://wiki.mozilla.org/Security/FirstPartyIsolation
// NOTICE: First-party isolation breaks Microsoft Teams
// NOTICE: First-party isolation causes HTTP basic auth to ask for credentials for every new tab (see #425)
pref("privacy.firstparty.isolate",				true);

// PREF: Make sure that third-party cookies (if enabled) never persist beyond the session.
// https://feeding.cloud.geek.nz/posts/tweaking-cookies-for-privacy-in-firefox/
// http://kb.mozillazine.org/Network.cookie.thirdparty.sessionOnly
// https://developer.mozilla.org/en-US/docs/Cookies_Preferences_in_Mozilla#network.cookie.thirdparty.sessionOnly
pref("network.cookie.thirdparty.sessionOnly",		true);

// PREF-DISABLED: Spoof User-agent (disabled)
//pref("general.useragent.override",				"Mozilla/5.0 (Windows NT 6.1; rv:45.0) Gecko/20100101 Firefox/45.0");
//pref("general.appname.override",				"Netscape");
//pref("general.appversion.override",			"5.0 (Windows)");
//pref("general.platform.override",				"Win32");
//pref("general.oscpu.override",				"Windows NT 6.1");

/*******************************************************************************
 * SECTION: Caching                                                            *
 ******************************************************************************/

// PREF-DISABLED: Permanently enable private browsing mode (disabled)
// https://support.mozilla.org/en-US/kb/Private-Browsing
// https://wiki.mozilla.org/PrivateBrowsing
// NOTICE-DISABLED: You can not view or inspect cookies when in private browsing: https://bugzilla.mozilla.org/show_bug.cgi?id=823941
// NOTICE-DISABLED: When Javascript is enabled, Websites can detect use of Private Browsing mode
// NOTICE-DISABLED: Private browsing breaks Kerberos authentication
// NOTICE-DISABLED: Disables "Containers" functionality (see below)
// NOTICE-DISABLED: "Always use private browsing mode" (browser.privatebrowsing.autostart) disables the possibility to use password manager: https://support.mozilla.org/en-US/kb/usernames-and-passwords-are-not-saved#w_private-browsing
//pref("browser.privatebrowsing.autostart",			true);

// PREF-DISABLED: Do not download URLs for the offline cache (disabled)
// http://kb.mozillazine.org/Browser.cache.offline.enable
//pref("browser.cache.offline.enable",			false);

// PREF-DISABLED: Clear history when Firefox closes (disabled)
// https://support.mozilla.org/en-US/kb/Clear%20Recent%20History#w_how-do-i-make-firefox-clear-my-history-automatically
// NOTICE-DISABLED: Installing user.js will remove your browsing history, caches and local storage.
// NOTICE-DISABLED: Installing user.js **will remove your saved passwords** (https://github.com/pyllyukko/user.js/issues/27)
// NOTICE-DISABLED: Clearing open windows on Firefox exit causes 2 windows to open when Firefox starts https://bugzilla.mozilla.org/show_bug.cgi?id=1334945
//pref("privacy.sanitize.sanitizeOnShutdown",		true);
//pref("privacy.clearOnShutdown.cache",			true);
//pref("privacy.clearOnShutdown.cookies",			true);
//pref("privacy.clearOnShutdown.downloads",			true);
//pref("privacy.clearOnShutdown.formdata",			true);
//pref("privacy.clearOnShutdown.history",			true);
//pref("privacy.clearOnShutdown.offlineApps",		true);
//pref("privacy.clearOnShutdown.sessions",			true);
//pref("privacy.clearOnShutdown.openWindows",		true);

// PREF: Set time range to "Everything" as default in "Clear Recent History"
pref("privacy.sanitize.timeSpan",				0);

// PREF: Clear everything but "Site Preferences" in "Clear Recent History"
pref("privacy.cpd.offlineApps",				true);
pref("privacy.cpd.cache",					true);
pref("privacy.cpd.cookies",				true);
pref("privacy.cpd.downloads",				true);
pref("privacy.cpd.formdata",				true);
pref("privacy.cpd.history",				true);
pref("privacy.cpd.sessions",				true);

// PREF-DISABLED: Don't remember browsing history (disabled)
//pref("places.history.enabled",				false);

// PREF-DISABLED: Don't remember recently closed tabs
//pref("browser.sessionstore.max_tabs_undo",		0);

// PREF-DISABLED: Disable disk cache
// http://kb.mozillazine.org/Browser.cache.disk.enable
//pref("browser.cache.disk.enable",				false);

// PREF-DISABLED: Disable memory cache (disabled)
// http://kb.mozillazine.org/Browser.cache.memory.enable
//pref("browser.cache.memory.enable",		false);

// PREF-DISABLED: Disable Caching of SSL Pages  (disabled)
// CIS Version 1.2.0 October 21st, 2011 2.5.8
// http://kb.mozillazine.org/Browser.cache.disk_cache_ssl
//pref("browser.cache.disk_cache_ssl",			false);

// PREF-DISABLED: Disable download history (disabled)
// CIS Version 1.2.0 October 21st, 2011 2.5.5
//pref("browser.download.manager.retention",			0);

// PREF: Disable password manager (use an external password manager!)
// CIS Version 1.2.0 October 21st, 2011 2.5.2
pref("signon.rememberSignons",				false);

// PREF: Disable form autofill, don't save information entered in web page forms and the Search Bar
pref("browser.formfill.enable",				false);

// PREF-DISABLED: Cookies expires at the end of the session (when the browser closes)
// http://kb.mozillazine.org/Network.cookie.lifetimePolicy#2
//pref("network.cookie.lifetimePolicy",			2);

// PREF: Require manual intervention to autofill known username/passwords sign-in forms
// http://kb.mozillazine.org/Signon.autofillForms
// https://www.torproject.org/projects/torbrowser/design/#identifier-linkability
pref("signon.autofillForms",				false);

// PREF: Disable formless login capture
// https://bugzilla.mozilla.org/show_bug.cgi?id=1166947
pref("signon.formlessCapture.enabled",			false);

// PREF: When username/password autofill is enabled, still disable it on non-HTTPS sites
// https://hg.mozilla.org/integration/mozilla-inbound/rev/f0d146fe7317
pref("signon.autofillForms.http",				false);

// PREF: Show in-content login form warning UI for insecure login fields
// https://hg.mozilla.org/integration/mozilla-inbound/rev/f0d146fe7317
pref("security.insecure_field_warning.contextual.enabled", true);

// PREF-DISABLED: Disable the password manager for pages with autocomplete=off (disabled)
// https://bugzilla.mozilla.org/show_bug.cgi?id=956906
// OWASP ASVS V9.1
// Does not prevent any kind of auto-completion (see browser.formfill.enable, signon.autofillForms)
//pref("signon.storeWhenAutocompleteOff",			false);

// PREF: Delete Search and Form History
// CIS Version 1.2.0 October 21st, 2011 2.5.6
pref("browser.formfill.expire_days",			0);

// PREF: Clear SSL Form Session Data
// http://kb.mozillazine.org/Browser.sessionstore.privacy_level#2
// Store extra session data for unencrypted (non-HTTPS) sites only.
// CIS Version 1.2.0 October 21st, 2011 2.5.7
// NOTE: CIS says 1, we use 2
pref("browser.sessionstore.privacy_level",			2);

// PREF: Delete temporary files on exit
// https://bugzilla.mozilla.org/show_bug.cgi?id=238789
pref("browser.helperApps.deleteTempFileOnExit",		true);

// PREF-DISABLED: Do not create screenshots of visited pages (relates to the "new tab page" feature) (disabled)
// https://support.mozilla.org/en-US/questions/973320
// https://developer.mozilla.org/en-US/docs/Mozilla/Preferences/Preference_reference/browser.pagethumbnails.capturing_disabled
//pref("browser.pagethumbnails.capturing_disabled",		true);

// PREF-DISABLED: Don't fetch and permanently store favicons for Windows .URL shortcuts created by drag and drop
// NOTICE: .URL shortcut files will be created with a generic icon
// Favicons are stored as .ico files in $profile_dir\shortcutCache
pref("browser.shell.shortcutFavicons",					false);

// PREF: Disable bookmarks backups (default: 15)
// http://kb.mozillazine.org/Browser.bookmarks.max_backups
pref("browser.bookmarks.max_backups", 0);

// PREF-DISABLED: Export bookmarks to HTML automatically when closing Firefox (disabled)
// https://support.mozilla.org/en-US/questions/1176242
//pref("browser.bookmarks.autoExportHTML", 				true);
//pref("browser.bookmarks.file",	'/path/to/bookmarks-export.html');

// PREF-DISABLED: Disable downloading of favicons in response to favicon fingerprinting techniques
// https://github.com/jonasstrehle/supercookie
// http://kb.mozillazine.org/Browser.chrome.site_icons
// https://blog.mozilla.org/security/2021/01/26/supercookie-protections/
//pref("browser.chrome.site_icons",				false);

/*******************************************************************************
 * SECTION: UI related                                                         *
 *******************************************************************************/

// PREF: Enable insecure password warnings (login forms in non-HTTPS pages)
// https://blog.mozilla.org/tanvi/2016/01/28/no-more-passwords-over-http-please/
// https://bugzilla.mozilla.org/show_bug.cgi?id=1319119
// https://bugzilla.mozilla.org/show_bug.cgi?id=1217156
pref("security.insecure_password.ui.enabled",		true);

// PREF-DISABLED: Disable right-click menu manipulation via JavaScript (disabled)
//pref("dom.event.contextmenu.enabled",		false);

// PREF-DISABLED: Disable "Are you sure you want to leave this page?" popups on page close  (disabled)
// https://support.mozilla.org/en-US/questions/1043508
// NOTICE: disabling "beforeunload" events may lead to losing data entered in web forms
// Does not prevent JS leaks of the page close event.
// https://developer.mozilla.org/en-US/docs/Web/Events/beforeunload
//pref("dom.disable_beforeunload",    true);

// PREF-DISABLED: Disable Downloading on Desktop
// CIS 2.3.2
pref("browser.download.folderList",			2);

// PREF: Always ask the user where to download
// https://developer.mozilla.org/en/Download_Manager_preferences (obsolete)
pref("browser.download.useDownloadDir",			false);

// PREF-DISABLED: Disable the "new tab page" and show a blank tab instead (disabled)
// https://wiki.mozilla.org/Privacy/Reviews/New_Tab
// https://support.mozilla.org/en-US/kb/new-tab-page-show-hide-and-customize-top-sites#w_how-do-i-turn-the-new-tab-page-off
//pref("browser.newtabpage.enabled",				false);
//pref("browser.newtab.url",					"about:blank");

// PREF: Disable Snippets
// https://wiki.mozilla.org/Firefox/Projects/Firefox_Start/Snippet_Service
// https://support.mozilla.org/en-US/kb/snippets-firefox-faq
pref("browser.newtabpage.activity-stream.feeds.snippets",	false);

// PREF: Disable Activity Stream
// https://wiki.mozilla.org/Firefox/Activity_Stream
pref("browser.newtabpage.activity-stream.enabled",		false);

// PREF: Disable new tab tile ads & preload
// http://www.thewindowsclub.com/disable-remove-ad-tiles-from-firefox
// http://forums.mozillazine.org/viewtopic.php?p=13876331#p13876331
// https://wiki.mozilla.org/Tiles/Technical_Documentation#Ping
// https://gecko.readthedocs.org/en/latest/browser/browser/DirectoryLinksProvider.html#browser-newtabpage-directory-source
// https://gecko.readthedocs.org/en/latest/browser/browser/DirectoryLinksProvider.html#browser-newtabpage-directory-ping
// TODO: deprecated? not in DXR, some dead links
pref("browser.newtabpage.enhanced",			false);
pref("browser.newtab.preload",				false);
pref("browser.newtabpage.directory.ping",			"");
pref("browser.newtabpage.directory.source",		"data:text/plain,{}");

// PREF: Disable Mozilla VPN ads on the about:protections page
// https://support.mozilla.org/en-US/kb/what-mozilla-vpn-and-how-does-it-work
// https://en.wikipedia.org/wiki/Mozilla_VPN
// https://blog.mozilla.org/security/2021/08/31/mozilla-vpn-security-audit/
// https://www.mozilla.org/en-US/security/advisories/mfsa2021-31/
pref("browser.vpn_promo.enabled",			false);

// PREF: Enable Auto Notification of Outdated Plugins (Firefox < 50)
// https://wiki.mozilla.org/Firefox3.6/Plugin_Update_Awareness_Security_Review
// CIS Version 1.2.0 October 21st, 2011 2.1.2
// https://hg.mozilla.org/mozilla-central/rev/304560
pref("plugins.update.notifyUser",				true);

// PREF: Force Punycode for Internationalized Domain Names
// http://kb.mozillazine.org/Network.IDN_show_punycode
// https://www.xudongz.com/blog/2017/idn-phishing/
// https://wiki.mozilla.org/IDN_Display_Algorithm
// https://en.wikipedia.org/wiki/IDN_homograph_attack
// https://www.mozilla.org/en-US/security/advisories/mfsa2017-02/
// CIS Mozilla Firefox 24 ESR v1.0.0 - 3.6
pref("network.IDN_show_punycode",				true);

// PREF: Disable inline autocomplete in URL bar  (disabled)
// http://kb.mozillazine.org/Inline_autocomplete
// pref("browser.urlbar.autoFill",				false);
// pref("browser.urlbar.autoFill.typed",			false);

// PREF-DISABLED: Disable CSS :visited selectors (disabled)
// https://blog.mozilla.org/security/2010/03/31/plugging-the-css-history-leak/
// https://dbaron.org/mozilla/visited-privacy
//pref("layout.css.visited_links_enabled",			false);

// PREF-DISABLED: Disable URL bar autocomplete and history/bookmarks suggestions dropdown (disabled)
// http://kb.mozillazine.org/Disabling_autocomplete_-_Firefox#Firefox_3.5
//pref("browser.urlbar.autocomplete.enabled",		false);

// PREF: Do not check if Firefox is the default browser
pref("browser.shell.checkDefaultBrowser",			false);

// PREF: When password manager is enabled, lock the password storage periodically
// CIS Version 1.2.0 October 21st, 2011 2.5.3 Disable Prompting for Credential Storage
pref("security.ask_for_password",				2);

// PREF: Lock the password storage every 1 minutes (default: 30)
pref("security.password_lifetime",				1);

// PREF: Display a notification bar when websites offer data for offline use
// http://kb.mozillazine.org/Browser.offline-apps.notify
pref("browser.offline-apps.notify",			true);

/******************************************************************************
 * SECTION: Cryptography                                                      *
 ******************************************************************************/

// PREF: Enable HTTPS-Only Mode
// https://blog.mozilla.org/security/2020/11/17/firefox-83-introduces-https-only-mode/
// https://www.feistyduck.com/bulletproof-tls-newsletter/issue_71_firefox_introduces_https_only_mode
pref("dom.security.https_only_mode",			true);

// PREF: Enable HSTS preload list (pre-set HSTS sites list provided by Mozilla)
// https://blog.mozilla.org/security/2012/11/01/preloading-hsts/
// https://wiki.mozilla.org/Privacy/Features/HSTS_Preload_List
// https://en.wikipedia.org/wiki/HTTP_Strict_Transport_Security
pref("network.stricttransportsecurity.preloadlist",	true);

// PREF: Enable Online Certificate Status Protocol
// https://en.wikipedia.org/wiki/Online_Certificate_Status_Protocol
// https://www.imperialviolet.org/2014/04/19/revchecking.html
// https://www.maikel.pro/blog/current-state-certificate-revocation-crls-ocsp/
// https://wiki.mozilla.org/CA:RevocationPlan
// https://wiki.mozilla.org/CA:ImprovingRevocation
// https://wiki.mozilla.org/CA:OCSP-HardFail
// https://news.netcraft.com/archives/2014/04/24/certificate-revocation-why-browsers-remain-affected-by-heartbleed.html
// https://news.netcraft.com/archives/2013/04/16/certificate-revocation-and-the-performance-of-ocsp.html
// NOTICE: OCSP leaks your IP and domains you visit to the CA when OCSP Stapling is not available on visited host
// NOTICE: OCSP is vulnerable to replay attacks when nonce is not configured on the OCSP responder
// NOTICE: OCSP adds latency (performance)
// NOTICE: Short-lived certificates are not checked for revocation (security.pki.cert_short_lifetime_in_days, default:10)
// CIS Version 1.2.0 October 21st, 2011 2.2.4
pref("security.OCSP.enabled",				1);

// PREF: Enable OCSP Stapling support
// https://en.wikipedia.org/wiki/OCSP_stapling
// https://blog.mozilla.org/security/2013/07/29/ocsp-stapling-in-firefox/
// https://www.digitalocean.com/community/tutorials/how-to-configure-ocsp-stapling-on-apache-and-nginx
pref("security.ssl.enable_ocsp_stapling",			true);

// PREF: Enable OCSP Must-Staple support (Firefox >= 45)
// https://blog.mozilla.org/security/2015/11/23/improving-revocation-ocsp-must-staple-and-short-lived-certificates/
// https://www.entrust.com/ocsp-must-staple/
// https://github.com/schomery/privacy-settings/issues/40
// NOTICE: Firefox falls back on plain OCSP when must-staple is not configured on the host certificate
pref("security.ssl.enable_ocsp_must_staple",		true);

// PREF: Require a valid OCSP response for OCSP enabled certificates
// https://groups.google.com/forum/#!topic/mozilla.dev.security/n1G-N2-HTVA
// Disabling this will make OCSP bypassable by MitM attacks suppressing OCSP responses
// NOTICE: `security.OCSP.require` will make the connection fail when the OCSP responder is unavailable
// NOTICE: `security.OCSP.require` is known to break browsing on some [captive portals](https://en.wikipedia.org/wiki/Captive_portal)
pref("security.OCSP.require",				true);

// PREF: Disable TLS Session Tickets
// https://www.blackhat.com/us-13/briefings.html#NextGen
// https://media.blackhat.com/us-13/US-13-Daigniere-TLS-Secrets-Slides.pdf
// https://media.blackhat.com/us-13/US-13-Daigniere-TLS-Secrets-WP.pdf
// https://bugzilla.mozilla.org/show_bug.cgi?id=917049
// https://bugzilla.mozilla.org/show_bug.cgi?id=967977
pref("security.ssl.disable_session_identifiers",		true);

// PREF: Only allow TLS 1.[2-3]
// http://kb.mozillazine.org/Security.tls.version.*
// 1 = TLS 1.0 is the minimum required / maximum supported encryption protocol. (This is the current default for the maximum supported version.)
// 2 = TLS 1.1 is the minimum required / maximum supported encryption protocol.
// 3 = TLS 1.2 is the minimum required / maximum supported encryption protocol.
// 4 = TLS 1.3 is the minimum required / maximum supported encryption protocol.
pref("security.tls.version.min",				3);
pref("security.tls.version.max",				4);

// PREF: Disable insecure TLS version fallback
// https://bugzilla.mozilla.org/show_bug.cgi?id=1084025
// https://github.com/pyllyukko/user.js/pull/206#issuecomment-280229645
pref("security.tls.version.fallback-limit",		4);

// PREF: Enforce Public Key Pinning
// https://en.wikipedia.org/wiki/HTTP_Public_Key_Pinning
// https://wiki.mozilla.org/SecurityEngineering/Public_Key_Pinning
// "2. Strict. Pinning is always enforced."
pref("security.cert_pinning.enforcement_level",		2);

// PREF: Disallow SHA-1
// https://bugzilla.mozilla.org/show_bug.cgi?id=1302140
// https://shattered.io/
pref("security.pki.sha1_enforcement_level",		1);

// PREF: Warn the user when server doesn't support RFC 5746 ("safe" renegotiation)
// https://wiki.mozilla.org/Security:Renegotiation#security.ssl.treat_unsafe_negotiation_as_broken
// https://web.nvd.nist.gov/view/vuln/detail?vulnId=CVE-2009-3555
pref("security.ssl.treat_unsafe_negotiation_as_broken",	true);

// PREF-DISABLED: Disallow connection to servers not supporting safe renegotiation (disabled)
// https://wiki.mozilla.org/Security:Renegotiation#security.ssl.require_safe_negotiation
// https://web.nvd.nist.gov/view/vuln/detail?vulnId=CVE-2009-3555
// TODO: `security.ssl.require_safe_negotiation` is more secure but makes browsing next to impossible (2012-2014-... - `ssl_error_unsafe_negotiation` errors), so is left disabled
//pref("security.ssl.require_safe_negotiation",		true);

// PREF: Disable automatic reporting of TLS connection errors
// https://support.mozilla.org/en-US/kb/certificate-pinning-reports
// we could also disable security.ssl.errorReporting.enabled, but I think it's
// good to leave the option to report potentially malicious sites if the user
// chooses to do so.
// you can test this at https://pinningtest.appspot.com/
pref("security.ssl.errorReporting.automatic",		false);

// PREF: Pre-populate the current URL but do not pre-fetch the certificate in the "Add Security Exception" dialog
// http://kb.mozillazine.org/Browser.ssl_override_behavior
// https://github.com/pyllyukko/user.js/issues/210
pref("browser.ssl_override_behavior",			1);

// PREF: Encrypted SNI (when TRR is enabled)
// https://www.cloudflare.com/ssl/encrypted-sni/
// https://wiki.mozilla.org/Trusted_Recursive_Resolver#ESNI
// https://en.wikipedia.org/wiki/Server_Name_Indication#Security_implications_(ESNI)
pref("network.security.esni.enabled",			true);

/******************************************************************************
 * SECTION: Cipher suites                                                     *
 ******************************************************************************/

// PREF: Disable null ciphers
pref("security.ssl3.rsa_null_sha",				false);
pref("security.ssl3.rsa_null_md5",				false);
pref("security.ssl3.ecdhe_rsa_null_sha",			false);
pref("security.ssl3.ecdhe_ecdsa_null_sha",			false);
pref("security.ssl3.ecdh_rsa_null_sha",			false);
pref("security.ssl3.ecdh_ecdsa_null_sha",			false);

// PREF: Disable SEED cipher
// https://en.wikipedia.org/wiki/SEED
pref("security.ssl3.rsa_seed_sha",				false);

// PREF: Disable 40/56/128-bit ciphers
// 40-bit ciphers
pref("security.ssl3.rsa_rc4_40_md5",			false);
pref("security.ssl3.rsa_rc2_40_md5",			false);
// 56-bit ciphers
pref("security.ssl3.rsa_1024_rc4_56_sha",			false);
// 128-bit ciphers
pref("security.ssl3.rsa_camellia_128_sha",			false);
pref("security.ssl3.ecdhe_rsa_aes_128_sha",		false);
pref("security.ssl3.ecdhe_ecdsa_aes_128_sha",		false);
pref("security.ssl3.ecdh_rsa_aes_128_sha",			false);
pref("security.ssl3.ecdh_ecdsa_aes_128_sha",		false);
pref("security.ssl3.dhe_rsa_camellia_128_sha",		false);
pref("security.ssl3.dhe_rsa_aes_128_sha",			false);

// PREF: Disable RC4
// https://developer.mozilla.org/en-US/Firefox/Releases/38#Security
// https://bugzilla.mozilla.org/show_bug.cgi?id=1138882
// https://rc4.io/
// https://web.nvd.nist.gov/view/vuln/detail?vulnId=CVE-2013-2566
pref("security.ssl3.ecdh_ecdsa_rc4_128_sha",		false);
pref("security.ssl3.ecdh_rsa_rc4_128_sha",			false);
pref("security.ssl3.ecdhe_ecdsa_rc4_128_sha",		false);
pref("security.ssl3.ecdhe_rsa_rc4_128_sha",		false);
pref("security.ssl3.rsa_rc4_128_md5",			false);
pref("security.ssl3.rsa_rc4_128_sha",			false);
pref("security.tls.unrestricted_rc4_fallback",		false);

// PREF: Disable 3DES (effective key size is < 128)
// https://en.wikipedia.org/wiki/3des#Security
// http://en.citizendium.org/wiki/Meet-in-the-middle_attack
// http://www-archive.mozilla.org/projects/security/pki/nss/ssl/fips-ssl-ciphersuites.html
pref("security.ssl3.dhe_dss_des_ede3_sha",			false);
pref("security.ssl3.dhe_rsa_des_ede3_sha",			false);
pref("security.ssl3.ecdh_ecdsa_des_ede3_sha",		false);
pref("security.ssl3.ecdh_rsa_des_ede3_sha",		false);
pref("security.ssl3.ecdhe_ecdsa_des_ede3_sha",		false);
pref("security.ssl3.ecdhe_rsa_des_ede3_sha",		false);
pref("security.ssl3.rsa_des_ede3_sha",			false);
pref("security.ssl3.rsa_fips_des_ede3_sha",		false);

// PREF: Disable ciphers with ECDH (non-ephemeral)
pref("security.ssl3.ecdh_rsa_aes_256_sha",			false);
pref("security.ssl3.ecdh_ecdsa_aes_256_sha",		false);

// PREF: Disable 256 bits ciphers without PFS
pref("security.ssl3.rsa_camellia_256_sha",			false);

// PREF: Enable GCM ciphers (TLSv1.2 only)
// https://en.wikipedia.org/wiki/Galois/Counter_Mode
pref("security.ssl3.ecdhe_ecdsa_aes_128_gcm_sha256",	true); // 0xc02b
pref("security.ssl3.ecdhe_rsa_aes_128_gcm_sha256",		true); // 0xc02f

// PREF: Enable ChaCha20 and Poly1305 (Firefox >= 47)
// https://www.mozilla.org/en-US/firefox/47.0/releasenotes/
// https://tools.ietf.org/html/rfc7905
// https://bugzilla.mozilla.org/show_bug.cgi?id=917571
// https://bugzilla.mozilla.org/show_bug.cgi?id=1247860
// https://cr.yp.to/chacha.html
pref("security.ssl3.ecdhe_ecdsa_chacha20_poly1305_sha256",	true);
pref("security.ssl3.ecdhe_rsa_chacha20_poly1305_sha256",	true);

// PREF: Disable ciphers susceptible to the logjam attack
// https://weakdh.org/
pref("security.ssl3.dhe_rsa_camellia_256_sha",		false);
pref("security.ssl3.dhe_rsa_aes_256_sha",			false);

// PREF: Disable ciphers with DSA (max 1024 bits)
pref("security.ssl3.dhe_dss_aes_128_sha",			false);
pref("security.ssl3.dhe_dss_aes_256_sha",			false);
pref("security.ssl3.dhe_dss_camellia_128_sha",		false);
pref("security.ssl3.dhe_dss_camellia_256_sha",		false);

// PREF-DISABLED: Ciphers with CBC & SHA-1 (disabled)
//pref("security.ssl3.rsa_aes_256_sha",			false); // 0x35
//pref("security.ssl3.rsa_aes_128_sha",			false); // 0x2f
//pref("security.ssl3.ecdhe_rsa_aes_256_sha",		false); // 0xc014
//pref("security.ssl3.ecdhe_ecdsa_aes_256_sha",		false); // 0xc00a

// PREF-DISABLED: Enable X25519Kyber768Draft00 (post-quantum key exchange) [FF Nightly 2024-01-18+]
// https://datatracker.ietf.org/doc/draft-tls-westerbaan-xyber768d00/
// https://twitter.com/bwesterb/status/1748017372764475519
// https://pq.cloudflareresearch.com/
//pref("security.tls.enable_kyber",				true);

/******************************************************************************
 * INTERFACE / USABILITY                                                      *
******************************************************************************/

// PREF: Abort after this number of HTTP redirections (default 20)
pref("network.http.redirection-limit", 10);

// PREF: Maximum number of simultaneously open popup windows (default 20)
pref("dom.popup_maximum", 10);

// PREF: Pressing [Backspace] will go back a page in the session history
// http://kb.mozillazine.org/Browser.backspace_action
pref("browser.backspace_action", 0);

// PREF: Do not paste clipboard contents on middle-click on Linux
// http://kb.mozillazine.org/Middlemouse.contentLoadURL
// http://kb.mozillazine.org/Middlemouse.paste
pref("middlemouse.contentLoadURL", false);
pref("middlemouse.paste", false);

// PREF: Let transmission handle magnet links
pref("network.protocol-handler.app.magnet", "/usr/bin/transmission-gtk");

// PREF: Allow scrolling on middle mouse button click
pref("general.autoScroll", true);

// PREF: Prompt for confirmation when closing the browser when more than one tab is open.
// http://kb.mozillazine.org/About:config_entries#Browser.
pref("browser.tabs.warnOnClose", true);

// PREF: Replace the window title bar with the tabs bar
pref("browser.tabs.inTitlebar", 1);

// PREF: Hide "know your rights" button on first run
pref("browser.rights.3.shown", false);

// PREF-DISABLED: Use custom startup homepage instead of about:home (disabled)
//pref("browser.startup.homepage", "/usr/share/ohmpage/index.html");

// PREF-DISABLED: Suppress Firefox Accounts "Welcome" page/"What's new" page after upgrades
// show a custom page instead
// https://github.com/nodiscc/ohmpage
//pref("startup.homepage_welcome_url", "");
//pref("startup.homepage_welcome_url.additional", "");
//pref("startup.homepage_override_url", "/usr/share/ohmpage/index.html");

// PREF: Display installed addons list by default in about:addons (instead of AMO homepage)
pref("extensions.ui.lastCategory", "addons://list/extension");

// PREF: Show new search bar menu including search engine buttons
pref("browser.search.showOneOffButtons", true);

// PREF: Set the default buttons/UI layout (addons in personal toolbar)
pref("browser.uiCustomization.state", "{\"placements\":{\"widget-overflow-fixed-list\":[\"feed-button\",\"containers-panelmenu\"],\"nav-bar\":[\"back-button\",\"forward-button\",\"stop-reload-button\",\"home-button\",\"urlbar-container\",\"search-container\",\"downloads-button\",\"library-button\",\"sidebar-button\",\"https-everywhere-eff_eff_org-browser-action\"],\"toolbar-menubar\":[\"menubar-items\"],\"TabsToolbar\":[\"tabbrowser-tabs\",\"new-tab-button\",\"alltabs-button\"],\"PersonalToolbar\":[\"personal-bookmarks\",\"fxa-toolbar-menu-button\",\"keepassxc-browser_keepassxc_org-browser-action\",\"ublock0_raymondhill_net-browser-action\",\"cookieautodelete_kennydo_com-browser-action\",\"https-everywhere_eff_org-browser-action\"]},\"seen\":[\"cookieautodelete_kennydo_com-browser-action\",\"https-everywhere_eff_org-browser-action\",\"ublock0_raymondhill_net-browser-action\",\"developer-button\",\"keepassxc-browser_keepassxc_org-browser-action\",\"https-everywhere-eff_eff_org-browser-action\"],\"dirtyAreaCache\":[\"PersonalToolbar\",\"nav-bar\",\"TabsToolbar\",\"toolbar-menubar\",\"PanelUI-contents\",\"widget-overflow-fixed-list\"],\"currentVersion\":16,\"newElementCount\":4}");

// PREF: always show the bookmarks toolbar
pref("browser.toolbars.bookmarks.visibility", "always");

// PREF-DISABLED: Show addon selection/review UI for preinstalled addons (disabled)
// https://blog.mozilla.org/addons/2011/08/11/strengthening-user-control-of-add-ons/
//pref("extensions.shownSelectionUI", true);

// PREF: Auto-enable these addons (disabled)
// https://github.com/yardenac/sext/blob/master/mozilla.cfg
//pref("extensions.enabledAddons", "");

// PREF-DISABLED: Enable HTTP pipelining (performance) (disabled for compatibility)
// https://developer.mozilla.org/en-US/docs/Web/HTTP/Connection_management_in_HTTP_1.x
//pref("network.http.pipelining", true);
//pref("network.http.pipelining.maxrequests", 8);
//pref("network.http.pipelining.ssl", true);

// PREF: Only store 3 previous history pages in memory (performance) (default: -1, automatic)
// http://kb.mozillazine.org/Browser.sessionhistory.max_total_viewers
pref("browser.sessionhistory.max_total_viewers", 3);

// PREF: Increase time between session save operations (default 15000) (performance)
// http://kb.mozillazine.org/Browser.sessionstore.interval
pref("browser.sessionstore.interval", 180000);

// PREF: Disable smooth scrolling (performance)
pref("general.smoothScroll", false);
pref("general.smoothScroll.pages", false);

// PREF: Force webGL acceleration (performance) (disabled)
// pref("layers.acceleration.force-enabled", true);
// pref("layers.offmainthreadcomposition.enabled", true);

// PREF: Enable WebRender (performance)
// https://wiki.mozilla.org/Platform/GFX/Quantum_Render
pref("gfx.webrender.all", true);

// Proxy preferences (performance) (disabled)
// pref("network.http.max-persistent-connections-per-proxy", 16);
// pref("network.http.max-persistent-connections-per-server", 16);
// pref("network.http.proxy.pipelining", true);

// PREF-DISABLED: Perform DNS lookups on remote SOCKS proxy server when a SOCKS proxy is enabled (disabled)
//pref("network.proxy.socks_remote_dns", true);

// PREF: Don't show cookie autodelete migration/settings dialog on first startup
pref("extensions.webextensions.ExtensionStorageIDB.migrated.CookieAutoDelete@kennydo.com", true);
